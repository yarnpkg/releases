'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.run = exports.noArguments = undefined;

var _asyncToGenerator2;

function _load_asyncToGenerator() {
  return _asyncToGenerator2 = _interopRequireDefault(require('babel-runtime/helpers/asyncToGenerator'));
}

let run = exports.run = (() => {
  var _ref = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (config, reporter, flags, args) {
    // add cwd module to the global registry
    const manifest = yield config.readRootManifest();
    const name = manifest.name;
    if (!name) {
      throw new (_errors || _load_errors()).MessageError(reporter.lang('unknownPackageName'));
    }

    const linkLoc = path.join(config.linkFolder, name);
    if (yield (_fs || _load_fs()).exists(linkLoc)) {
      throw new (_errors || _load_errors()).MessageError(reporter.lang('linkCollision', name));
    } else {
      yield (_fs || _load_fs()).symlink(config.cwd, linkLoc);
      reporter.success(reporter.lang('linkRegistered', name));
      reporter.info(reporter.lang('linkInstallMessage'));
    }
  });

  return function run(_x, _x2, _x3, _x4) {
    return _ref.apply(this, arguments);
  };
})();

var _errors;

function _load_errors() {
  return _errors = require('../../errors.js');
}

var _fs;

function _load_fs() {
  return _fs = _interopRequireWildcard(require('../../util/fs.js'));
}

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const noArguments = exports.noArguments = true;

const path = require('path');