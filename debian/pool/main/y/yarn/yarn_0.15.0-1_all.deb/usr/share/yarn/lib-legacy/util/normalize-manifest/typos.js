'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  dependancies: 'dependencies',
  dependecies: 'dependencies',
  depdenencies: 'dependencies',
  devEependencies: 'devDependencies',
  depends: 'dependencies',
  'dev-dependencies': 'devDependencies',
  devDependences: 'devDependencies',
  devDepenencies: 'devDependencies',
  devdependencies: 'devDependencies',
  repostitory: 'repository',
  repo: 'repository',
  prefereGlobal: 'preferGlobal',
  hompage: 'homepage',
  hampage: 'homepage',
  autohr: 'author',
  autor: 'author',
  contributers: 'contributors',
  publicationConfig: 'publishConfig',
  script: 'scripts'
};