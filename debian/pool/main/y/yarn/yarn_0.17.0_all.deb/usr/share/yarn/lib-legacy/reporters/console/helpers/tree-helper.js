'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const repeat = require('repeating');

// types


// public
const sortTrees = exports.sortTrees = trees => {
  return trees.sort(function (tree1, tree2) {
    return tree1.name.localeCompare(tree2.name);
  });
};

const recurseTree = exports.recurseTree = (tree, level, recurseFunc) => {
  const treeLen = tree.length;
  const treeEnd = treeLen - 1;
  for (let i = 0; i < treeLen; i++) {
    recurseFunc(tree[i], level + 1, i === treeEnd);
  }
};

const getFormattedOutput = exports.getFormattedOutput = fmt => {
  const item = formatColor(fmt.color, fmt.name, fmt.formatter);
  const indent = getIndent(fmt.end, fmt.level);
  const suffix = getSuffix(fmt.hint, fmt.formatter);
  return `${ indent }─ ${ item }${ suffix }\n`;
};

// private
const getIndentChar = end => {
  return end ? '└' : '├';
};

const getIndent = (end, level) => {
  const base = repeat('│  ', level);
  const indentChar = getIndentChar(end);
  const hasLevel = base + indentChar;
  return level ? hasLevel : indentChar;
};

const getSuffix = (hint, formatter) => {
  return hint ? ` (${ formatter.grey(hint) })` : '';
};

const formatColor = (color, strToFormat, formatter) => {
  return color ? formatter[color](strToFormat) : strToFormat;
};