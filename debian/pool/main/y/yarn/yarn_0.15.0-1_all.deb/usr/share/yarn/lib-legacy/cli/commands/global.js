'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setFlags = exports.run = undefined;

var _set;

function _load_set() {
  return _set = _interopRequireDefault(require('babel-runtime/core-js/set'));
}

var _keys;

function _load_keys() {
  return _keys = _interopRequireDefault(require('babel-runtime/core-js/object/keys'));
}

var _asyncToGenerator2;

function _load_asyncToGenerator() {
  return _asyncToGenerator2 = _interopRequireDefault(require('babel-runtime/helpers/asyncToGenerator'));
}

var _promise;

function _load_promise() {
  return _promise = _interopRequireDefault(require('babel-runtime/core-js/promise'));
}

let updateCwd = (() => {
  var _ref = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (config) {
    yield config.init({ cwd: config.globalFolder });
  });

  return function updateCwd(_x) {
    return _ref.apply(this, arguments);
  };
})();

let getBins = (() => {
  var _ref2 = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (config) {
    // build up list of registry folders to search for binaries
    const dirs = [];
    for (const registryName of (0, (_keys || _load_keys()).default)((_index || _load_index()).registries)) {
      const registry = config.registries[registryName];
      dirs.push(registry.loc);
    }

    // build up list of binary files
    const paths = new (_set || _load_set()).default();
    for (const dir of dirs) {
      const binDir = path.join(dir, '.bin');
      if (!(yield (_fs || _load_fs()).exists(binDir))) {
        continue;
      }

      for (const name of yield (_fs || _load_fs()).readdir(binDir)) {
        paths.add(path.join(binDir, name));
      }
    }
    return paths;
  });

  return function getBins(_x2) {
    return _ref2.apply(this, arguments);
  };
})();

let checkOwnership = (() => {
  var _ref3 = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (cwd, binLoc) {
    // fully resolve if a symlink
    binLoc = yield (_fs || _load_fs()).realpath(binLoc);

    // check if the path is now inside our cwd
    if (binLoc.startsWith(cwd)) {
      return true;
    }

    // TODO check if it's a file that starts with YARN-BIN which will be inserted by cmd-shim

    return false;
  });

  return function checkOwnership(_x3, _x4) {
    return _ref3.apply(this, arguments);
  };
})();

let initUpdateBins = (() => {
  var _ref4 = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (config, reporter) {
    const beforeBins = yield getBins(config);

    const binFolder = '/Users/sebmck/Scratch/test-global';

    return (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* () {
      const afterBins = yield getBins(config);

      // remove old bins
      for (const src of beforeBins) {
        if (afterBins.has(src)) {
          // not old
          continue;
        }

        // remove old bin
        const dest = path.join(binFolder, path.basename(src));
        if (!(yield (_fs || _load_fs()).exists(dest))) {
          // doesn't exist
          continue;
        }

        // check if this bin belongs to us
        const owned = yield checkOwnership(config.cwd, dest);
        if (owned) {
          yield (_fs || _load_fs()).unlink(dest);
        } else {
          reporter.warn(`Refusing to delete binary at ${ dest } as it doesn't appear to be owned by us.`);
        }
      }

      // add new bins
      for (const src of afterBins) {
        if (beforeBins.has(src)) {
          // already inserted
          continue;
        }

        // insert new bin
        const dest = path.join(binFolder, path.basename(src));
        if (yield (_fs || _load_fs()).exists(dest)) {
          const owned = yield checkOwnership(config.cwd, dest);
          if (owned) {
            yield (_fs || _load_fs()).unlink(dest);
          } else {
            reporter.warn(`Cannot add binary ${ src } as there already exists one at ${ dest }`);
            continue;
          }
        }

        //
        yield (0, (_packageLinker || _load_packageLinker()).linkBin)(src, dest);
      }
    });
  });

  return function initUpdateBins(_x5, _x6) {
    return _ref4.apply(this, arguments);
  };
})();

var _index;

function _load_index() {
  return _index = require('../../registries/index.js');
}

var _baseReporter;

function _load_baseReporter() {
  return _baseReporter = _interopRequireDefault(require('../../reporters/base-reporter.js'));
}

var _buildSubCommands2;

function _load_buildSubCommands() {
  return _buildSubCommands2 = _interopRequireDefault(require('./_build-sub-commands.js'));
}

var _wrapper;

function _load_wrapper() {
  return _wrapper = _interopRequireDefault(require('../../lockfile/wrapper.js'));
}

var _install;

function _load_install() {
  return _install = require('./install.js');
}

var _add;

function _load_add() {
  return _add = require('./add.js');
}

var _remove;

function _load_remove() {
  return _remove = require('./remove.js');
}

var _packageLinker;

function _load_packageLinker() {
  return _packageLinker = require('../../package-linker.js');
}

var _fs;

function _load_fs() {
  return _fs = _interopRequireWildcard(require('../../util/fs.js'));
}

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class GlobalAdd extends (_add || _load_add()).Add {
  maybeOutputSaveTree() {
    for (const pattern of this.args) {
      const manifest = this.resolver.getStrictResolvedPattern(pattern);
      _ls(manifest, this.reporter, true);
    }
    return (_promise || _load_promise()).default.resolve();
  }

  _logSuccessSaveLockfile() {
    // noop
  }
}

const path = require('path');

function _ls(manifest, reporter, saved) {
  const bins = manifest.bin ? (0, (_keys || _load_keys()).default)(manifest.bin) : [];
  const human = `${ manifest.name }@${ manifest.version }`;
  if (bins.length) {
    if (saved) {
      reporter.success(`Installed ${ human } with binaries:`);
    } else {
      reporter.info(`${ human } has binaries:`);
    }
    reporter.list(`bins-${ manifest.name }`, bins);
  } else if (saved) {
    reporter.warn(`${ human } has no binaries`);
  }
}

var _buildSubCommands = (0, (_buildSubCommands2 || _load_buildSubCommands()).default)('global', {
  add: (() => {
    var _ref6 = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (config, reporter, flags, args) {
      yield updateCwd(config);

      const updateBins = yield initUpdateBins(config, reporter);

      // install module
      const lockfile = yield (_wrapper || _load_wrapper()).default.fromDirectory(config.cwd);
      const install = new GlobalAdd(args, flags, config, reporter, lockfile);
      yield install.init();

      // link binaries
      yield updateBins();
    });

    function add(_x7, _x8, _x9, _x10) {
      return _ref6.apply(this, arguments);
    }

    return add;
  })(),
  ls: (() => {
    var _ref7 = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (config, reporter, flags, args) {
      yield updateCwd(config);

      // install so we get hard file paths
      const lockfile = yield (_wrapper || _load_wrapper()).default.fromDirectory(config.cwd);
      const install = new (_install || _load_install()).Install({ skipIntegrity: true }, config, new (_baseReporter || _load_baseReporter()).default(), lockfile);
      const patterns = yield install.init();

      // dump global modules
      for (const pattern of patterns) {
        const manifest = install.resolver.getStrictResolvedPattern(pattern);
        _ls(manifest, reporter, false);
      }
    });

    function ls(_x11, _x12, _x13, _x14) {
      return _ref7.apply(this, arguments);
    }

    return ls;
  })(),
  remove: (() => {
    var _ref8 = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (config, reporter, flags, args) {
      yield updateCwd(config);

      const updateBins = yield initUpdateBins(config, reporter);

      // remove module
      yield (0, (_remove || _load_remove()).run)(config, reporter, flags, args);

      // remove binaries
      yield updateBins();
    });

    function remove(_x15, _x16, _x17, _x18) {
      return _ref8.apply(this, arguments);
    }

    return remove;
  })()
});

const run = _buildSubCommands.run;
const setFlags = _buildSubCommands.setFlags;
exports.run = run;
exports.setFlags = setFlags;