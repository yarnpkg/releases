'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.en = undefined;

var _en;

function _load_en() {
  return _en = _interopRequireDefault(require('./en.js'));
}

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.en = (_en || _load_en()).default;