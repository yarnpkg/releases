'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.run = exports.requireLockfile = undefined;

var _keys;

function _load_keys() {
  return _keys = _interopRequireDefault(require('babel-runtime/core-js/object/keys'));
}

var _promise;

function _load_promise() {
  return _promise = _interopRequireDefault(require('babel-runtime/core-js/promise'));
}

var _slicedToArray2;

function _load_slicedToArray() {
  return _slicedToArray2 = _interopRequireDefault(require('babel-runtime/helpers/slicedToArray'));
}

var _asyncToGenerator2;

function _load_asyncToGenerator() {
  return _asyncToGenerator2 = _interopRequireDefault(require('babel-runtime/helpers/asyncToGenerator'));
}

// Prompt user with Inquirer
let prompt = (() => {
  var _ref = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (choices) {
    let pageSize;
    if (process.stdout instanceof tty.WriteStream) {
      pageSize = process.stdout.rows - 2;
    }
    const answers = yield (_inquirer || _load_inquirer()).default.prompt([{
      name: 'packages',
      type: 'checkbox',
      message: 'Choose which packages to update.',
      choices: choices,
      pageSize: pageSize,
      validate: function validate(answer) {
        return !!answer.length || 'You must choose at least one package.';
      }
    }]);
    return answers.packages;
  });

  return function prompt(_x) {
    return _ref.apply(this, arguments);
  };
})();

let run = exports.run = (() => {
  var _ref2 = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (config, reporter, flags, args) {
    const lockfile = yield (_wrapper || _load_wrapper()).default.fromDirectory(config.cwd);
    const install = new (_install || _load_install()).Install(flags, config, reporter, lockfile);

    var _ref3 = yield install.fetchRequestFromCwd();

    var _ref4 = (0, (_slicedToArray2 || _load_slicedToArray()).default)(_ref3, 1);

    const deps = _ref4[0];


    const allDeps = yield (_promise || _load_promise()).default.all(deps.map((() => {
      var _ref6 = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (_ref5) {
        let pattern = _ref5.pattern;
        let hint = _ref5.hint;

        const locked = lockfile.getLocked(pattern);
        if (!locked) {
          throw new (_errors || _load_errors()).MessageError(reporter.lang('lockfileOutdated'));
        }

        const name = locked.name;
        const current = locked.version;

        let latest = '';
        let wanted = '';

        const normalized = (_packageRequest || _load_packageRequest()).default.normalizePattern(pattern);

        if ((_packageRequest || _load_packageRequest()).default.getExoticResolver(pattern) || (_packageRequest || _load_packageRequest()).default.getExoticResolver(normalized.range)) {
          latest = wanted = 'exotic';
        } else {
          var _ref7 = yield config.registries[locked.registry].checkOutdated(config, name, normalized.range);

          latest = _ref7.latest;
          wanted = _ref7.wanted;
        }

        return { name: name, current: current, wanted: wanted, latest: latest, hint: hint };
      });

      return function (_x6) {
        return _ref6.apply(this, arguments);
      };
    })()));

    const isDepOld = function isDepOld(_ref8) {
      let latest = _ref8.latest;
      let current = _ref8.current;
      return latest !== 'exotic' && semver.lt(current, latest);
    };
    const isDepExpected = function isDepExpected(_ref9) {
      let current = _ref9.current;
      let wanted = _ref9.wanted;
      return current === wanted;
    };
    const orderByExpected = function orderByExpected(depA, depB) {
      return isDepExpected(depA) && !isDepExpected(depB) ? 1 : -1;
    };

    const outdatedDeps = allDeps.filter(isDepOld).sort(orderByExpected);

    if (!outdatedDeps.length) {
      reporter.success(reporter.lang('allDependenciesUpToDate'));
      return;
    }

    const getNameFromHint = function getNameFromHint(hint) {
      return hint ? `${ hint }Dependencies` : 'dependencies';
    };

    const maxLengthArr = { name: 0, current: 0, latest: 0 };
    outdatedDeps.forEach(function (dep) {
      return ['name', 'current', 'latest'].forEach(function (key) {
        maxLengthArr[key] = Math.max(maxLengthArr[key], dep[key].length);
      });
    });

    // Depends on maxLengthArr
    const addPadding = function addPadding(dep) {
      return function (key) {
        return `${ dep[key] }${ (0, (_repeating || _load_repeating()).default)(' ', maxLengthArr[key] - dep[key].length) }`;
      };
    };

    const colorizeName = function colorizeName(_ref10) {
      let current = _ref10.current;
      let wanted = _ref10.wanted;
      return current === wanted ? reporter.format.yellow : reporter.format.red;
    };

    const makeRow = function makeRow(dep) {
      const padding = addPadding(dep);
      const name = colorizeName(dep)(padding('name'));
      const current = reporter.format.blue(padding('current'));
      const latest = reporter.format.green(padding('latest'));
      return `${ name }  ${ current }  ❯  ${ latest }`;
    };

    const groupedDeps = outdatedDeps.reduce(function (acc, dep) {
      const hint = dep.hint;
      const name = dep.name;
      const latest = dep.latest;

      const key = getNameFromHint(hint);
      const xs = acc[key] || [];
      acc[key] = xs.concat({
        name: makeRow(dep),
        value: dep,
        short: `${ name }@${ latest }`
      });
      return acc;
    }, {});

    const flatten = function flatten(xs) {
      return xs.reduce(function (ys, y) {
        return ys.concat(Array.isArray(y) ? flatten(y) : y);
      }, []);
    };

    const choices = (0, (_keys || _load_keys()).default)(groupedDeps).map(function (key) {
      return [new (_inquirer || _load_inquirer()).default.Separator(reporter.format.bold.underline.green(key)), groupedDeps[key], new (_inquirer || _load_inquirer()).default.Separator(' ')];
    });

    const answers = yield prompt(flatten(choices));

    const getName = function getName(_ref11) {
      let name = _ref11.name;
      return name;
    };
    const isHint = function isHint(x) {
      return function (_ref12) {
        let hint = _ref12.hint;
        return hint === x;
      };
    };

    yield [null, 'dev', 'optional', 'peer'].reduce((() => {
      var _ref13 = (0, (_asyncToGenerator2 || _load_asyncToGenerator()).default)(function* (promise, hint) {
        // Wait for previous promise to resolve
        yield promise;
        // Reset dependency flags
        flags.dev = hint === 'dev';
        flags.peer = hint === 'peer';
        flags.optional = hint === 'optional';

        const deps = answers.filter(isHint(hint)).map(getName);
        if (deps.length) {
          reporter.info(reporter.lang('updateInstalling', getNameFromHint(hint)));
          const add = new (_add || _load_add()).Add(deps, flags, config, reporter, lockfile);
          return yield add.init();
        }
        return (_promise || _load_promise()).default.resolve();
      });

      return function (_x7, _x8) {
        return _ref13.apply(this, arguments);
      };
    })(), (_promise || _load_promise()).default.resolve());
  });

  return function run(_x2, _x3, _x4, _x5) {
    return _ref2.apply(this, arguments);
  };
})();

exports.setFlags = setFlags;

var _inquirer;

function _load_inquirer() {
  return _inquirer = _interopRequireDefault(require('inquirer'));
}

var _repeating;

function _load_repeating() {
  return _repeating = _interopRequireDefault(require('repeating'));
}

var _errors;

function _load_errors() {
  return _errors = require('../../errors.js');
}

var _packageRequest;

function _load_packageRequest() {
  return _packageRequest = _interopRequireDefault(require('../../package-request.js'));
}

var _add;

function _load_add() {
  return _add = require('./add.js');
}

var _install;

function _load_install() {
  return _install = require('./install.js');
}

var _wrapper;

function _load_wrapper() {
  return _wrapper = _interopRequireDefault(require('../../lockfile/wrapper.js'));
}

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const tty = require('tty');

const semver = require('semver');

const requireLockfile = exports.requireLockfile = true;

function setFlags(commander) {
  // TODO: support some flags that install command has
  commander.usage('update');
}